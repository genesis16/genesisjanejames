<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'genesis' );

/** MySQL database username */
define( 'DB_USER', 'genesis' );

/** MySQL database password */
define( 'DB_PASSWORD', 'fL^s4&H5xF01' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'p+bSdgOjQRR]*,O#l)+<0l-uqiVUa?3L#68/Y@{ABDY0AE]_.lQ{b Kg52 5_h(.' );
define( 'SECURE_AUTH_KEY',  '*$Fru S|`w.8E*g_2$wZRKm{A5<l9?FwB#OZWu]OpmaJ[ 7*08m3snU|r:3RK^iR' );
define( 'LOGGED_IN_KEY',    'hv6wxxY0$M<}b[T`bdtt8u0jWYpDcyR5%Sk_)^!I+LJUPsfw;L*~CVKi)x2zMD!S' );
define( 'NONCE_KEY',        'V0wMsaN*Ka%hSZb^t/kqa?iu(;^wfbXfNF}yP:|3JrJh#qD2}m4DrS3Gy?j_xlgy' );
define( 'AUTH_SALT',        'I^x(SuUgr&_Hi8k~[8l%U:>CfdQ9!D4=Q`C!u?H.PR_6t-0%ua7;`[l6BA?-Up/Q' );
define( 'SECURE_AUTH_SALT', '(MtJSQQ=>E@y&B/AbDSex=q:K9nCJ$!-#D+<Rzo}l~2i31+.w</`9b&{1TR 9u-R' );
define( 'LOGGED_IN_SALT',   '_:_C1t2F6!q?a61r_J?n>C(KUu@:]KzvF?k4Ht<FfE_s}ViwV- f TM+JKRa{sY/' );
define( 'NONCE_SALT',       'il?]Nz|-A1ngvk2h!HZ=#Y|cBba}Cw5):7^Y3Agc*doR#m|FzPSgPA}B|pX(ULyt' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG_DISPLAY', true);
define( 'WP_DEBUG_LOG', true 
'/wp-content/debug.log);

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define('WP_DEBUG_LOG', ABSPATH . '/wp-content/debug.log');
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
